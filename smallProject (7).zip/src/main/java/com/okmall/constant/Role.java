package com.okmall.constant;

public enum Role {
    USER, ADMIN
}