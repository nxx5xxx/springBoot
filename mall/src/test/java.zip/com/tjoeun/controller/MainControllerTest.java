package com.tjoeun.controller;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class MainControllerTest {

	@Test
	@DisplayName("로그인테스트")
	void test() {
		fail("Not yet implemented");
	}

}
