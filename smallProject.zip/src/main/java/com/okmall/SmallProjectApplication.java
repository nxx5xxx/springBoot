package com.okmall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmallProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmallProjectApplication.class, args);
	}

}
