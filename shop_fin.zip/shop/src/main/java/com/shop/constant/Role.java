package com.shop.constant;

public enum Role {
    USER, ADMIN
}