package com.okmall.constant;

public enum OrderStatus {
    ORDER, CANCEL
}