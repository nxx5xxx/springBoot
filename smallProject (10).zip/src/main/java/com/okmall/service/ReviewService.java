package com.okmall.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.okmall.entity.Review;
import com.okmall.repository.ReviewImgRepository;
import com.okmall.repository.ReviewRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ReviewService {
	private final ReviewRepository reviewRepository;
	private final ReviewImgRepository reviewImgRepository;
	
	//모두 불러오기
	public List<Review> findAll(){
		return reviewRepository.findAll();
	}
	
}
