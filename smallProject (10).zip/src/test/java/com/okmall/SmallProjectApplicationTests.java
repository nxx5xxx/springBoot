package com.okmall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmallProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
