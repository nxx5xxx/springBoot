package com.okmall.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}